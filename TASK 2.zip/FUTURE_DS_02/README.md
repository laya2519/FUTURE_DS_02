# FUTURE_DS_02 — Customer Retention & Churn Analysis

**Internship:** Future Interns — Data Science & Analytics Track
**Task 2 of 3**

## 📌 Task
Analyze customer data to identify churn patterns, key retention drivers, and customer
lifetime trends for a subscription-based business.

## 🛠 Tools Used
Python — Pandas, NumPy, Matplotlib, Seaborn (Jupyter Notebook)

## 📂 Repository Structure
```
FUTURE_DS_02/
├── data/
│   ├── customer_churn_data.csv   # synthetic subscription customer dataset
│   └── kpi_summary.csv           # headline KPI figures
├── images/
│   ├── 01_overall_churn_rate.png
│   ├── 02_churn_by_contract.png
│   ├── 03_churn_by_tenure.png
│   └── 04_monthly_charges_by_churn.png
├── notebook.ipynb                # full analysis notebook
└── README.md
```

## 📊 Key Performance Indicators
| Metric | Value |
|---|---|
| Overall Churn Rate | 14.88% |
| Total Customers | 4,000 |
| Retained Customers | ~3,405 |
| Churned Customers | ~595 |

## 📈 Visuals
| Overall Churn vs Retention | Churn by Contract Type |
|---|---|
| ![churn pie](images/01_overall_churn_rate.png) | ![contract](images/02_churn_by_contract.png) |

| Churn by Tenure Cohort | Monthly Charges: Churned vs Retained |
|---|---|
| ![tenure](images/03_churn_by_tenure.png) | ![charges](images/04_monthly_charges_by_churn.png) |

## 💡 Key Insights & Recommendations
1. **Month-to-month contracts churn ~10x more** than 2-year contracts — incentivize longer
   commitments with loyalty discounts.
2. **First 6 months** is the highest-risk period for churn — introduce a structured onboarding
   journey with proactive check-ins.
3. Higher **support ticket volume** correlates with higher churn — invest in faster, proactive
   customer support.
4. **Auto-pay customers churn less** — promote auto-pay enrollment with small incentives.
5. Retained customers carry a significantly higher lifetime value — even modest churn
   reduction has an outsized long-term revenue impact.

## 🚀 How to Run
```bash
pip install pandas numpy matplotlib seaborn jupyter
jupyter notebook notebook.ipynb
```

---
*Part of the Future Interns Data Science & Analytics internship deliverables.*
